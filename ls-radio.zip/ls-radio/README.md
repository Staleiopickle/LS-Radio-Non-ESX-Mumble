# ls-radio-mumble

Modified ls-radio [https://github.com/alcapone-dev/ls-radio] for Mumble-voip
